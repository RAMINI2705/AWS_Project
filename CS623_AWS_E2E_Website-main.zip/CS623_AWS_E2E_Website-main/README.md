# We use following major commands in our project 

## To check for any new updates on the EC2 instance. 

sudo apt-get update

## For installing Sql-client
sudo apt-get install mysql-client

## For installing python and related frameworks

sudo apt-get install python3

sudo apt-get install python3-flask

sudo apt-get install python3-pymysql

sudo apt-get install python3-boto3

## for running application
sudo python3 Empapp.py
